// alert("hello")
// confirm("are you sure")


function myFunction()
{
//   console.log("Hello", a, b, c);
    //  console.log(document);
    //  console.log(typeof document); //obect

    // console.log(document.getElementById('x1'));
    // console.log(typeof document.getElementById('x1'));

    
    //DOM Method--getElementById()
    //DOM Property--value
    var amount=document.getElementById('x1').value;
    var rateOfInterest=document.getElementById('x2').value;
    var duration=document.getElementById('x3').value;
    // console.log(amount,rateOfInterest,duration);
    // console.log(typeof amount,typeof rateOfInterest,typeof duration);
    if(amount==""||rateOfInterest==""||duration=="")
    {
        alert("Please enter all values")
    }
    else
    {
       amount=parseInt(amount);
       rateOfInterest=parseFloat(rateOfInterest);
       duration=parseInt(duration);

       var openingBalance=amount;
       for(var i=1; i<=duration; i++)
       {
          var emi=
          console.log(emi);
       }

    }

   
}