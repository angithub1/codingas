namespace BasicWebApp.Services;

public class Employee
{
    //Student id
    public int Id { get; set; }
    public string EmpName { get; set; }
    public decimal EmpSalary { get; set; }
    public int EmpAge { get; set; }

    //Foreign key
    public int DepartmentId { get; set; }
    
}