namespace BasicWebApp.Services;

public class Department
{
    public int Id { get; set; }

    public string DeptName { get; set; }

    public string DeptLoc { get; set; }

    //Navigation property
    public List<Employee> Employess { get; set; }
}