global using Microsoft.EntityFrameworkCore;
namespace BasicWebApp.Services;

public class FactoryDbContext : DbContext
{
    public DbSet<Department> Departments { get; set; }

    public DbSet<Employee> Employees { get; set; }

    //Connecting to database

   protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
   {
       optionsBuilder.UseSqlServer("Server=(localdb)\\MyEmp;Database=Factory");
   }


   //Mapping using fluent API
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>()
        .ToTable("Department")
        .Property(p => p.Id)
        .HasColumnName("DeptNo");

        modelBuilder.Entity<Employee>()
        .ToTable("Employee")
        .Property(p => p.Id)
        .HasColumnName("EmpNo");

        modelBuilder.Entity<Employee>()
         .Property(p => p.DepartmentId)
        .HasColumnName("DeptNo");

    }

}