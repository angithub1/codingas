using BasicWebApp.Services;
namespace BasicWebApp.Controllers;
using Microsoft.AspNetCore.Mvc;


public class DetailController : Controller
{
    
   [HttpGet]
   [Route("Detail/Details/{id}")]
    public IActionResult Details(int id)
    {
        var db = new FactoryDbContext();
        var did = id;
        //ViewBag.did = did;
        ViewBag.model = db.Employees
                   .Where(d=>d.DepartmentId==did)
                   .ToList();

        return View("Details");



    }
}