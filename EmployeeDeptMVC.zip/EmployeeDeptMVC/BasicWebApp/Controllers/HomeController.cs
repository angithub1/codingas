namespace BasicWebApp.Controllers;


public class HomeController : Controller
{
    public IActionResult Index([FromServices] BasicWebApp.Services.FactoryDbContext db)
    {
      return View(db);
    }
}
