namespace BasicWebApp.Services;

public class SimpleInterest : ISiCalculator
{
    public String GetInterest(int principal, int period, double rate)
    {
        return ((principal * period * rate) / 100).ToString("for simple interest = 0.000");

    }
}