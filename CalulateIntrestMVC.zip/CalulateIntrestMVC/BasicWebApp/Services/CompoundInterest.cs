namespace BasicWebApp.Services;

public class CompoundInterest : ISiCalculator
{
    public String GetInterest(int principal, int period, double rate)
    {
           // String s="0.00";
          double amount = principal *(Math.Pow(1+ rate/100,period));
          double res = (amount - principal);
            return res.ToString("for compound interest is = 0.000");
    }
}