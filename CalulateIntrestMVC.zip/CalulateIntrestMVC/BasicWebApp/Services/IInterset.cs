namespace BasicWebApp.Services;

public interface ISiCalculator
{
    String GetInterest(int principal, int period, double rate);
    
}
