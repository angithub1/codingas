
using BasicWebApp.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<ISiCalculator, SimpleInterest>();
//builder.Services.AddSingleton<ISiCalculator, CompoundInterest>();
var app = builder.Build();
app.UseStaticFiles();
app.MapPost("/calculate", DoCalculation);
app.Run();

async Task DoCalculation(HttpRequest request, HttpResponse response, ISiCalculator compute)
{
    int x = int.Parse(request.Form["principal"]);
    int y = int.Parse(request.Form["period"]);
    double z =double.Parse(request.Form["rate"]);
    
        await response.WriteAsync(@$"
            <html>
                <head>
                    <title>BasicWebApp</title>
                </head>
                <body style=background-color:black;color:white;>
                    <i>The highest form of pure thought is in mathematics</i><br>
                    <p> </p>
                    <b>The calculated interest  </b>{compute.GetInterest(x, y, z)}
                </body>
            </html>
        ");
    }


