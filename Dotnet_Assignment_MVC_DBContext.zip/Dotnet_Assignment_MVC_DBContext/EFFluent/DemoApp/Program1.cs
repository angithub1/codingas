using Data;


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<EntityDbContext>();

var app = builder.Build();
app.MapDefaultControllerRoute();
app.Run();