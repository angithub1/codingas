﻿using college;

var sah = new EntityDbContext();

if(args.Length == 0)
{
    foreach(var cr in sah.Courses) //Printing all info about courses
        Console.WriteLine("{0,-6}{1, 12}{2,10}",cr.Id,cr.Course_name,cr.Fees );
}
else
{
    int crno = int.Parse(args[0]);
    var stu = sah.Courses
            .Where(p => p.Id == crno) //checking condition for foreign key
            .Include(p => p.Entities)
            .FirstOrDefault();
if(stu != null)
{
    foreach(var entity in stu.Entities)
        Console.WriteLine("{0,-6}{1, 12}{2,10}{3,12}{4,6}",entity.Id,entity.Student_Name,entity.Age,entity.CourseId,entity.Grade);
}            
}