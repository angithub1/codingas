namespace controller;
using Data;
public class HomeController:Controller
{
     
    public IActionResult Index([FromServices] Data.EntityDbContext db)
    {
        
        //Current= db.Courses.Find(101);
        //db.Entry(Current).Collection(p => p.Entities).Load();
        return View(db);
    }

}