namespace controller;
using Data;
public class DetailController:Controller
{
    
    [HttpGet]
    [Route("Detail/Details/{id:int}")]
    public IActionResult Details(int id)
    {
        var db = new EntityDbContext();

        var cid = id;

        ViewBag.cid = cid;
        var model = db.Courses
                   .Where(p=>p.Id==cid)
                   .Include(p=>p.Entities)
                   .FirstOrDefault();
        
        return View(model);
    }
}