namespace Data;

public class Student
{
    //Student Id
    public int Id { get; set; }

    public string Student_Name { get; set; }

    public int Age { get; set; }

    //Course Id(Foreign Key)
    public int CourseId { get; set; }

    public string Grade {get; set;}
}