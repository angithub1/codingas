namespace Data;

public class Course
{
    public int Id { get; set; }

    public string Course_name { get; set; }

    public int Fees { get; set; }

    //Navigation Property
    public List<Student> Entities { get; set; }
}
