global using Microsoft.EntityFrameworkCore;

namespace Data; 

public class EntityDbContext : DbContext
{
    public DbSet<Course> Courses { get; set;}

    public DbSet<Student> Students{ get; set;}

    // Connecting To DataBase
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseMySQL("Server=localhost;Database=college;User ID=root;Password=root");

    }    

    //Mapping Using Fluent API
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Student>()
            .ToTable("student")
            .Property(p => p.Id)
            .HasColumnName("Student_Id");
            
        modelBuilder.Entity<Student>()
            .Property(p => p.CourseId)
            .HasColumnName("Course_Id");
            
        modelBuilder.Entity<Course>()
            .ToTable("course")
            .Property(p => p.Id)
            .HasColumnName("Course_Id");
    }
}