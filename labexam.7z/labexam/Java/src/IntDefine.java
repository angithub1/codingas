package utility;
public interface IntDefine {

	public boolean isNegative();

	public boolean isPositive();

	public boolean isZero();

	public boolean isOdd();

	public boolean isEven();

}


