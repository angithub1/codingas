using StudentInfo;

//C# supports top-level statements

/*
if(args.Length==0)
{

Date date = new Date(04,02,1998);
Student std = new Student(101, "Anis", date, 82, 75, 89);
Console.WriteLine("The Student id : {0}\nStudent Name : {1}\nStudent DOB {2}", std.Id, std.Name,std.date.Day, std.date.Month, std.date.Year);
Console.WriteLine("English Marks : {3}\nMaths marks : {4}\nScience marks : {5}", std.MarksOfEng, std.MarksOfMath, std.MarksOfScience);

}

else
{*/
    
int a = int.Parse(args[0]);
string b = args[1];
int c = int.Parse(args[2]);
int d = int.Parse(args[3]);
int e = int.Parse(args[4]);

//creating ann instance of student class
Student std = new Student(a, b, c, d, e);
Console.WriteLine("The Student id : {0}\nStudent Name : {1}\nEnglish Marks : {2}\nMaths marks : {3}\nScience marks : {4}", std.Id, std.Name, std.MarksOfEng, std.MarksOfMath, std.MarksOfScience );

//}