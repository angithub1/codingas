namespace StudentInfo;

public class Student 
{
    public int Id { get; set;}
    public string Name { get; set;}
    //public Date date { get; set;}

    public int MarksOfEng { get; set;}
    public int MarksOfMath { get; set;}

    public int MarksOfScience { get; set;}

    public Student(int sid, string name, int eng, int math, int sci)
    {
        Id = sid;
        Name = name;
       // date = dob;
        MarksOfEng = eng;
        MarksOfMath = math;
        MarksOfScience = sci;
    }



}