﻿using Company;

Console.WriteLine("Select your category Enter 1 for Full time staff or Enter 2 Part time staff");
Console.WriteLine("========================================");
int input = int.Parse(Console.ReadLine());

switch(input)
{
    case 1 : 
          ICollection<FullTimeStaff> fstaff = EachStaff.GetFStaff();
          foreach(var entry in fstaff)
              entry.Print();
              break;

    case 2 : 
          ICollection<PartTimeStaff> pstaff = EachStaff.GetPStaff();
          foreach(var entry in pstaff)
              entry.Print();
              break;
}

public class EachStaff
{
    public static ICollection<FullTimeStaff> GetFStaff()
    {
    var staff = new List<FullTimeStaff>();

    staff.Add(new FullTimeStaff("vijay","chennai","Sales",35000));
    staff.Add(new FullTimeStaff("nick","hyderabad","Engineering",35000));
    staff.Add(new FullTimeStaff("mayur","kolkata","IT",35000));
    return staff;
    }


    public static ICollection<PartTimeStaff> GetPStaff()
    {
    var staff = new List<PartTimeStaff>();

    staff.Add(new PartTimeStaff("prash","mumbai",120,300));
    staff.Add(new PartTimeStaff("vicky","pune",150,500));
    staff.Add(new PartTimeStaff("john","banglore",180,280));
    return staff;
    }

}


