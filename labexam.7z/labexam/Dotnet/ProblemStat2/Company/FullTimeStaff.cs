namespace Company;

//Class FullTimeStaff inherits from Staff abstract class
public class FullTimeStaff : Staff
{
  public string Department { get; set; } 

  public double Salary { get; set; } 


  //parameterized constructor
  public FullTimeStaff(string Name, string Address, string dept, double sal) : base(Name, Address)
  {
    Department = dept;
    Salary = sal;
  }

  //Parameterless constructor
  public FullTimeStaff() : this("jack", "berlin", "Engineer", 65000)
  {

  }

   public override void Print()
   {
    Console.WriteLine($"The Employee {Name} lives at {Address} works for {Department} Department and has a salary {Salary}");
   }
}
