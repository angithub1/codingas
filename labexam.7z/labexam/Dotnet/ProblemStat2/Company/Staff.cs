﻿namespace Company;

//class with abstract modifier 
//in which you cannot create an instance of the class
public  abstract class Staff
{
   public string Name { get; set; } 

   public string Address { get; set; } 

//parameterized constructor
   public Staff(string name, string address)
   {
      Name=name;
      Address=address;
   }
//Parameterless constructor
   public Staff() : this("jane", "london")
   {

   }

   public abstract void Print();
}
