namespace Company;

//Class FullTimeStaff inherits from Staff abstract class
public class PartTimeStaff : Staff
{
  public int NoOfHours { get; set; } 

  public int RatePerHour { get; set; } 


  //parameterized constructor
  public PartTimeStaff(string Name, string Address, int hours, int rate) : base(Name, Address)
  {
    NoOfHours = hours;
    RatePerHour = rate;
  }

  //Parameterless constructor
  public PartTimeStaff() : this("jill", "dubai", 100, 250)
  {

  }

   public override void Print()
   {
    Console.WriteLine($"The Employee {Name} lives at {Address} worked for {NoOfHours} hours and rate is {RatePerHour}");
   }
}